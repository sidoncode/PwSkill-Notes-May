const AWS = require('aws-sdk');

const Client = new AWS.DynamoDB.DocumentClient({region: 'us-east-1'});
const bucketName = "whizlabs-dynamodb-s3";
const filePath = "myfile1.csv";
var SID, name, course;

exports.handler = (event, context, callback) => {
    var parameter = {
        TableName: 'mydynamoDB',
        Limit: 10
    };

    Client.scan(parameter, function(err,data) {
        if(err)
        callback(err, null);
        else
        {
            var JsonArray = data.Items;
            console.info(JsonArray);
            var csvdata = "";
            csvdata = JsonToCSV(JsonArray);
            console.info("\nCSV File content\n"+ csvdata);

            putObjectToS3(bucketName,filePath,csvdata);
            callback(null,"200 : Success");
        }
    });
};

function JsonToCSV(JsonArray){
    var fields = ["Sid", "Name", "Course"];
    var csvStr = fields.join(",") + "\n";

    JsonArray.forEach(element => {
                SID = element.Sid;
                name = element.Name;
                course  = element.Course;

                csvStr += SID + ',' + name + ','  + course + "\n";
                });
                return csvStr;
}

function putObjectToS3(bucket, key, data){
    var s3 = new AWS.S3();
        var params = {
            Bucket : bucket,
            Key : key,
            Body : data
        };
        s3.putObject(params, function(err, data) {
          if (err) 
          console.log(err, err.stack); // an error occurred
          else     
          console.info("\n\nFile "+key+" Created\n");           // successful response
        });
}
